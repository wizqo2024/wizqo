import React from 'react';
import { UnifiedNavigation } from '../components/UnifiedNavigation';
import { Footer } from '../components/Footer';

export function TermsPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <UnifiedNavigation currentPage="terms" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-black text-slate-900 mb-6">
            Terms of <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">Service</span>
          </h1>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-xl prose prose-lg mx-auto">
          <section className="mb-8">
            <h2 className="text-2xl font-semibold">1. Acceptance of Terms</h2>
            <p>By accessing Wizqo, you agree to be bound by these Terms of Service and our Privacy Policy. If you do not agree, please discontinue use.</p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">2. Use of Service</h2>
            <p>
              You must be 13 years or older to use Wizqo. You agree not to use the platform for any unlawful purpose or to violate any applicable laws.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">3. User Content</h2>
            <p>
              You retain ownership of any data or content you submit. You grant us a non-exclusive license to use that content for delivering and improving our services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">4. Modifications</h2>
            <p>
              We may update or modify these terms at any time. Continued use of the service after changes implies acceptance of the new terms.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">5. Disclaimer of Warranty</h2>
            <p>
              Wizqo is provided "as is" without warranties of any kind. We do not guarantee the accuracy or completeness of any learning material.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">6. Limitation of Liability</h2>
            <p>
              Wizqo shall not be liable for any indirect, incidental, or consequential damages arising from your use of the service.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">7. Termination</h2>
            <p>
              We reserve the right to terminate or suspend your account for violations of these terms, with or without notice.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">8. Governing Law</h2>
            <p>
              These terms are governed by the laws of [Insert Your Jurisdiction, e.g., UAE]. Any disputes shall be resolved in the courts of that jurisdiction.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold">9. Contact</h2>
            <p>
              For questions about these Terms, contact us at <a href="mailto:admin@wizqo.com" className="text-blue-600 hover:text-blue-800 transition-colors">admin@wizqo.com</a>.
            </p>
          </section>
        </div>
      </div>

      <Footer />
    </div>
  );
}