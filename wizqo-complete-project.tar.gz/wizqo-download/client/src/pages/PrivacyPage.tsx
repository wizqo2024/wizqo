import React from 'react';
import { UnifiedNavigation } from '../components/UnifiedNavigation';
import { Footer } from '../components/Footer';

export function PrivacyPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      <UnifiedNavigation currentPage="privacy" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-black text-slate-900 mb-6">
            Privacy <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">Policy</span>
          </h1>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-xl prose prose-lg mx-auto">
          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">1. Who We Are</h2>
            <p className="text-gray-700 mb-4">
              Wizqo is an AI-powered platform that delivers personalized 7-day hobby learning plans. This Privacy Policy explains how we collect, use, and safeguard your data while using our services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">2. Information We Collect</h2>
            <p className="text-gray-700 mb-4">We collect the following types of data:</p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Personal Information: name, email address, hobby preferences</li>
              <li>Usage Data: pages visited, session duration, click behavior</li>
              <li>Technical Data: browser type, device info, IP address</li>
              <li>Cookies and similar technologies for personalization and analytics</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">3. How We Use Your Information</h2>
            <p className="text-gray-700 mb-4">We use your information to:</p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Personalize your 7-day hobby learning experience</li>
              <li>Improve platform performance and user experience</li>
              <li>Communicate updates, tips, or new features (only if you opt in)</li>
              <li>Monitor usage trends and troubleshoot issues</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">4. Sharing Your Information</h2>
            <p className="text-gray-700 mb-4">
              We do not sell your data. We may share limited information with trusted third parties (e.g., analytics, hosting) only to support service delivery. All partners are contractually bound to data protection standards.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">5. International Transfers</h2>
            <p className="text-gray-700 mb-4">
              If your data is transferred outside your country, we ensure appropriate safeguards are in place such as Standard Contractual Clauses or equivalent measures.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">6. Data Retention</h2>
            <p className="text-gray-700 mb-4">
              We retain personal data as long as necessary to fulfill our services and legal obligations. You may request deletion at any time.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">7. Security</h2>
            <p className="text-gray-700 mb-4">
              We implement SSL encryption, secure server hosting, and access control to protect your information. No system is 100% secure, so we encourage strong passwords and cautious use.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">8. Your Rights</h2>
            <p className="text-gray-700 mb-4">You may:</p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Access, update, or delete your data</li>
              <li>Withdraw consent at any time</li>
              <li>Request data portability</li>
              <li>Opt out of marketing communications</li>
            </ul>
            <p className="text-gray-700 mt-4">To exercise these rights, contact us at <a href="mailto:admin@wizqo.com" className="text-blue-600 hover:text-blue-800 transition-colors">admin@wizqo.com</a>.</p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">9. Children's Privacy</h2>
            <p className="text-gray-700 mb-4">
              Wizqo is not intended for children under 13. If we learn we've collected data from a minor, we will delete it promptly.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">10. Policy Updates</h2>
            <p className="text-gray-700 mb-4">
              We may update this Privacy Policy periodically. Material changes will be posted here and, if applicable, emailed to you.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">11. Contact Us</h2>
            <p className="text-gray-700">
              If you have any questions or requests about your data or this policy, please contact us at{" "}
              <a href="mailto:admin@wizqo.com" className="text-blue-600 hover:text-blue-800 transition-colors">
                admin@wizqo.com
              </a>.
            </p>
          </section>
        </div>
      </div>

      <Footer />
    </div>
  );
}