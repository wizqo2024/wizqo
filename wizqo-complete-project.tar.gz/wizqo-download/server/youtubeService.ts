// YouTube API Service with quality filters
import fetch from 'node-fetch';

interface YouTubeVideo {
  videoId: string;
  title: string;
  duration: string;
  publishedAt: string;
  channelTitle: string;
}

// Parse YouTube duration format (PT1H2M3S) to minutes
function parseDuration(duration: string): number {
  const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 0;
  
  const hours = parseInt(match[1] || '0', 10);
  const minutes = parseInt(match[2] || '0', 10);
  const seconds = parseInt(match[3] || '0', 10);
  
  return hours * 60 + minutes + (seconds > 30 ? 1 : 0); // Round up if more than 30 seconds
}

// Test if video is available and working
async function isVideoWorking(videoId: string): Promise<boolean> {
  try {
    const response = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
    return response.ok;
  } catch {
    return false;
  }
}

// Search YouTube with quality filters
export async function searchYouTubeVideos(
  hobby: string,
  experience: string,
  dayNumber: number,
  maxResults: number = 10
): Promise<YouTubeVideo[]> {
  const youtubeApiKey = process.env.YOUTUBE_API_KEY;
  
  if (!youtubeApiKey) {
    console.log('⚠️ YouTube API key not found');
    return [];
  }

  try {
    // Create targeted search query
    const searchTerms = [
      hobby,
      experience === 'beginner' ? 'beginner tutorial' : `${experience} tutorial`,
      dayNumber === 1 ? 'basics fundamentals' : `lesson ${dayNumber}`,
      '2024 2023 2022 2021 2020 2019' // Prefer recent videos
    ];
    
    const searchQuery = searchTerms.join(' ');
    const encodedQuery = encodeURIComponent(searchQuery);

    // Search for videos (published after 2018, medium duration)
    const searchUrl = `https://www.googleapis.com/youtube/v3/search?` +
      `part=snippet&` +
      `maxResults=${maxResults}&` +
      `q=${encodedQuery}&` +
      `type=video&` +
      `key=${youtubeApiKey}&` +
      `order=relevance&` +
      `publishedAfter=2018-01-01T00:00:00Z&` +
      `videoDuration=medium&` +
      `videoEmbeddable=true&` +
      `regionCode=US&` +
      `relevanceLanguage=en`;

    console.log(`🔍 YouTube Search: ${hobby} ${experience} day ${dayNumber}`);
    
    const searchResponse = await fetch(searchUrl);
    if (!searchResponse.ok) {
      throw new Error(`YouTube search failed: ${searchResponse.status}`);
    }

    const searchData = await searchResponse.json() as any;
    
    if (!searchData.items || searchData.items.length === 0) {
      console.log('🚫 No videos found in search');
      return [];
    }

    // Get video IDs for details lookup
    const videoIds = searchData.items.map((item: any) => item.id.videoId).join(',');
    
    // Get detailed video information including duration
    const detailsUrl = `https://www.googleapis.com/youtube/v3/videos?` +
      `part=contentDetails,snippet,statistics&` +
      `id=${videoIds}&` +
      `key=${youtubeApiKey}`;

    const detailsResponse = await fetch(detailsUrl);
    if (!detailsResponse.ok) {
      throw new Error(`YouTube details failed: ${detailsResponse.status}`);
    }

    const detailsData = await detailsResponse.json() as any;
    
    // Filter and process videos
    const qualityVideos: YouTubeVideo[] = [];
    
    for (const video of detailsData.items) {
      const duration = video.contentDetails.duration;
      const title = video.snippet.title.toLowerCase();
      const publishDate = new Date(video.snippet.publishedAt);
      const cutoffDate = new Date('2018-01-01');
      const durationMinutes = parseDuration(duration);
      
      // Apply all quality filters
      const isRecentEnough = publishDate >= cutoffDate;
      const isShortEnough = durationMinutes <= 45 && durationMinutes >= 3; // 3-45 minutes
      const isRelevant = title.includes(hobby) || title.includes('tutorial') || title.includes('learn') || title.includes('how to');
      const isNotLive = video.snippet.liveBroadcastContent !== 'live';
      const hasGoodStats = parseInt(video.statistics?.viewCount || '0') > 1000; // At least 1k views
      
      if (isRecentEnough && isShortEnough && isRelevant && isNotLive && hasGoodStats) {
        // Test video availability
        const isWorking = await isVideoWorking(video.id);
        if (isWorking) {
          qualityVideos.push({
            videoId: video.id,
            title: video.snippet.title,
            duration: duration,
            publishedAt: video.snippet.publishedAt,
            channelTitle: video.snippet.channelTitle
          });
          
          console.log(`✅ Quality video found: ${video.snippet.title} (${durationMinutes}min)`);
        } else {
          console.log(`🚫 Video not working: ${video.snippet.title}`);
        }
      } else {
        console.log(`❌ Filtered out: ${video.snippet.title} (${durationMinutes}min, ${publishDate.getFullYear()})`);
      }
    }

    return qualityVideos;
    
  } catch (error) {
    console.error('YouTube API error:', error);
    return [];
  }
}

// Get best video for specific day and hobby with content matching
export async function getBestVideoForDay(
  hobby: string,
  experience: string,
  dayNumber: number,
  dayTitle?: string,
  mainTask?: string
): Promise<string> {
  console.log(`🎥 YouTube API: Searching for ${hobby} ${experience} day ${dayNumber} - "${dayTitle}"`);
  
  // Create more specific search based on day content
  const searchTerms = [];
  if (dayTitle) {
    // Extract key concepts from day title
    const titleWords = dayTitle.toLowerCase().split(' ').filter(word => 
      word.length > 3 && !['day', 'the', 'and', 'for', 'with', 'your'].includes(word)
    );
    searchTerms.push(...titleWords);
  }
  
  if (mainTask) {
    // Extract key concepts from main task
    const taskWords = mainTask.toLowerCase().split(' ').filter(word => 
      word.length > 3 && !['learn', 'practice', 'complete', 'exercise', 'technique'].includes(word)
    );
    searchTerms.push(...taskWords);
  }
  
  // Create targeted search query
  const specificQuery = [hobby, experience, 'tutorial', ...searchTerms.slice(0, 3)].join(' ');
  console.log(`🔍 Specific search: "${specificQuery}"`);
  
  const videos = await searchYouTubeVideosWithCustomQuery(specificQuery, 15);
  
  if (videos.length === 0) {
    console.log('🔄 No specific videos found, trying general search');
    const generalVideos = await searchYouTubeVideos(hobby, experience, dayNumber, 15);
    if (generalVideos.length === 0) {
      console.log('🔄 No API videos found, using fallback');
      return getFallbackVideo(hobby, dayNumber);
    }
    return selectBestVideo(generalVideos, hobby, dayTitle, mainTask);
  }

  return selectBestVideo(videos, hobby, dayTitle, mainTask);
}

// Search YouTube with custom query
async function searchYouTubeVideosWithCustomQuery(
  searchQuery: string,
  maxResults: number = 10
): Promise<YouTubeVideo[]> {
  const youtubeApiKey = process.env.YOUTUBE_API_KEY;
  
  if (!youtubeApiKey) {
    return [];
  }

  try {
    const encodedQuery = encodeURIComponent(searchQuery);

    const searchUrl = `https://www.googleapis.com/youtube/v3/search?` +
      `part=snippet&` +
      `maxResults=${maxResults}&` +
      `q=${encodedQuery}&` +
      `type=video&` +
      `key=${youtubeApiKey}&` +
      `order=relevance&` +
      `publishedAfter=2018-01-01T00:00:00Z&` +
      `videoDuration=medium&` +
      `videoEmbeddable=true&` +
      `regionCode=US&` +
      `relevanceLanguage=en`;

    const searchResponse = await fetch(searchUrl);
    if (!searchResponse.ok) {
      throw new Error(`YouTube search failed: ${searchResponse.status}`);
    }

    const searchData = await searchResponse.json() as any;
    
    if (!searchData.items || searchData.items.length === 0) {
      return [];
    }

    // Get video details
    const videoIds = searchData.items.map((item: any) => item.id.videoId).join(',');
    
    const detailsUrl = `https://www.googleapis.com/youtube/v3/videos?` +
      `part=contentDetails,snippet,statistics&` +
      `id=${videoIds}&` +
      `key=${youtubeApiKey}`;

    const detailsResponse = await fetch(detailsUrl);
    if (!detailsResponse.ok) {
      return [];
    }

    const detailsData = await detailsResponse.json() as any;
    
    const qualityVideos: YouTubeVideo[] = [];
    
    for (const video of detailsData.items) {
      const duration = video.contentDetails.duration;
      const durationMinutes = parseDuration(duration);
      
      if (durationMinutes <= 45 && durationMinutes >= 3) {
        const isWorking = await isVideoWorking(video.id);
        if (isWorking) {
          qualityVideos.push({
            videoId: video.id,
            title: video.snippet.title,
            duration: duration,
            publishedAt: video.snippet.publishedAt,
            channelTitle: video.snippet.channelTitle
          });
        }
      }
    }

    return qualityVideos;
    
  } catch (error) {
    console.error('YouTube custom search error:', error);
    return [];
  }
}

// Select best video based on content matching
function selectBestVideo(
  videos: YouTubeVideo[],
  hobby: string,
  dayTitle?: string,
  mainTask?: string
): string {
  if (videos.length === 0) {
    return getFallbackVideo(hobby, 1);
  }

  // Score videos based on relevance to day content
  const scoredVideos = videos.map(video => {
    let score = 0;
    const title = video.title.toLowerCase();
    const duration = parseDuration(video.duration);
    
    // Basic relevance
    if (title.includes(hobby)) score += 10;
    if (title.includes('tutorial')) score += 8;
    if (title.includes('beginner')) score += 6;
    if (title.includes('learn')) score += 6;
    if (title.includes('how to')) score += 6;
    
    // Content matching bonus
    if (dayTitle) {
      const titleWords = dayTitle.toLowerCase().split(' ');
      titleWords.forEach(word => {
        if (word.length > 3 && title.includes(word)) {
          score += 5;
        }
      });
    }
    
    if (mainTask) {
      const taskWords = mainTask.toLowerCase().split(' ');
      taskWords.forEach(word => {
        if (word.length > 3 && title.includes(word)) {
          score += 5;
        }
      });
    }
    
    // Duration preference (10-25 minutes is ideal)
    if (duration >= 10 && duration <= 25) score += 5;
    else if (duration >= 5 && duration <= 35) score += 3;
    
    // Recency bonus
    const publishYear = new Date(video.publishedAt).getFullYear();
    if (publishYear >= 2023) score += 5;
    else if (publishYear >= 2021) score += 3;
    else if (publishYear >= 2019) score += 1;
    
    return { ...video, score };
  });

  // Sort by score and return best video
  scoredVideos.sort((a, b) => b.score - a.score);
  const bestVideo = scoredVideos[0];
  
  console.log(`🏆 Best video selected: ${bestVideo.title} (Score: ${bestVideo.score})`);
  return bestVideo.videoId;
}

// Fallback videos for when API fails
function getFallbackVideo(hobby: string, dayNumber: number): string {
  const fallbackVideos: { [key: string]: string[] } = {
    guitar: ["3jWRrafhO7M", "F9vWVucRJzo", "7tpQr0Xh6yM", "VJPCkS-wZR4", "kXOcz1_qnXw", "w8L3f3DWlNs", "Qa7GNfwLQJo"],
    yoga: ["v7AYKMP6rOE", "xQgP8N7jCrE", "Vg5FeCTzB6w", "h8TKF2_p7qU", "R7CJ8NGFV4A", "L9qWnJGJz8Y", "M8Hb2Y5QN3w"],
    cooking: ["rtR63-ecUNo", "fBYVFCb1n6s", "jQWBWn7dcR8", "L3dDHKjr_P8", "dNGgJa8r_7s", "mGz7d8xB1V8", "K2nV8JGFgh4"],
    drawing: ["pMC0Cx3Uk5g", "ewMksAbPdas", "S0SxlqltDBo", "wgDNDOKnArk", "7BDKWT3pI_A", "vqbOW8K_bsI", "dWMc3Gz9Zd0"],
    coding: ["UB1O30fR-EE", "hdI2bqOjy3c", "t_ispmWmdjY", "W6NZfCO5SIk", "c8aAYU5m4jM", "9Yf36xdLp2A", "rfscVS0vtbw"],
    photography: ["B9FzVhw8_bY", "DJ_DIYDqWGY", "pwmJRx0eJiQ", "R8MzHddV-Z0", "mKY4gUEjAVs", "L9qWnJGJz8Y", "M8Hb2Y5QN3w"],
    painting: ["7BDKWT3pI_A", "vqbOW8K_bsI", "dWMc3Gz9Zd0", "pMC0Cx3Uk5g", "ewMksAbPdas", "S0SxlqltDBo", "wgDNDOKnArk"]
  };
  
  const videos = fallbackVideos[hobby.toLowerCase()] || fallbackVideos.guitar;
  return videos[Math.min(dayNumber - 1, videos.length - 1)];
}