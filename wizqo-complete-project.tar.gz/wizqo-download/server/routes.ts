import type { Express } from "express";
import { createServer, type Server } from "http";
import { sendContactEmail } from './email.js';
import { getTargetedYouTubeVideo, getVideoDetails } from './videoSelection.js';
import { getBestVideoForDay } from './youtubeService.js';
import { validateHobby, getVideosForHobby, suggestAlternativeHobbies } from './hobbyValidator.js';
import { storage } from './storage.js';
import { insertHobbyPlanSchema, insertUserProgressSchema } from '@shared/schema';
import { z } from 'zod';

console.log('📖 API: Database storage initialized for all operations');

// Fixed plan data field mapping function
function fixPlanDataFields(plan: any) {
  if (!plan || !plan.days) return plan;
  
  return {
    ...plan,
    days: plan.days.map((day: any) => ({
      ...day,
      // Handle "Avoid These Mistakes" section with various possible field names
      commonMistakes: day.commonMistakes && day.commonMistakes.length > 0 
        ? day.commonMistakes 
        : day.mistakesToAvoid && day.mistakesToAvoid.length > 0
          ? day.mistakesToAvoid
          : day.avoidMistakes && day.avoidMistakes.length > 0
            ? day.avoidMistakes
            : [
              "Rushing through exercises without understanding concepts",
              "Skipping practice time or cutting sessions short", 
              "Not taking notes or tracking your improvement"
            ]
    }))
  };
}

// Enhanced YouTube video mapping for fallback plans
function getYouTubeVideos(hobby: string): string[] {
  const videos: { [key: string]: string[] } = {
    guitar: ["3jWRrafhO7M", "F9vWVucRJzo", "7tpQr0Xh6yM", "VJPCkS-wZR4", "kXOcz1_qnXw", "w8L3f3DWlNs", "Qa7GNfwLQJo"],
    cooking: ["rtR63-ecUNo", "fBYVFCb1n6s", "jQWBWn7dcR8", "L3dDHKjr_P8", "dNGgJa8r_7s", "mGz7d8xB1V8", "K2nV8JGFgh4"], 
    drawing: ["pMC0Cx3Uk5g", "ewMksAbPdas", "S0SxlqltDBo", "wgDNDOKnArk", "7BDKWT3pI_A", "vqbOW8K_bsI", "dWMc3Gz9Zd0"],
    coding: ["UB1O30fR-EE", "hdI2bqOjy3c", "t_ispmWmdjY", "W6NZfCO5SIk", "c8aAYU5m4jM", "9Yf36xdLp2A", "rfscVS0vtbw"],
    photography: ["B9FzVhw8_bY", "DJ_DIYDqWGY", "pwmJRx0eJiQ", "R8MzHddV-Z0", "mKY4gUEjAVs", "L9qWnJGJz8Y", "M8Hb2Y5QN3w"],
    painting: ["7BDKWT3pI_A", "vqbOW8K_bsI", "dWMc3Gz9Zd0", "pMC0Cx3Uk5g", "ewMksAbPdas", "S0SxlqltDBo", "wgDNDOKnArk"],
    yoga: ["R7CJ8NGFV4A", "xQgP8N7jCrE", "Vg5FeCTzB6w", "h8TKF2_p7qU", "mKY4gUEjAVs", "L9qWnJGJz8Y", "M8Hb2Y5QN3w"]
  };
  
  return videos[hobby.toLowerCase()] || videos.guitar;
}

// DeepSeek AI integration for dynamic plan generation
async function generateAIPlan(hobby: string, experience: string, timeAvailable: string, goal: string) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  const youtubeApiKey = process.env.YOUTUBE_API_KEY;
  
  if (!apiKey) {
    console.log('⚠️ No DeepSeek API key found, using fallback plan generation');
    return generateFallbackPlan(hobby, experience, timeAvailable, goal);
  }

  try {
    const prompt = `Generate a comprehensive 7-day learning plan for learning ${hobby}. 

User details:
- Experience level: ${experience}
- Time available per day: ${timeAvailable}
- Learning goal: ${goal}

Return ONLY a JSON object with this exact structure:
{
  "hobby": "${hobby}",
  "title": "Master ${hobby.charAt(0).toUpperCase() + hobby.slice(1)} in 7 Days",
  "description": "A personalized learning plan description",
  "difficulty": "${experience}",
  "totalDays": 7,
  "days": [
    {
      "day": 1,
      "title": "Day title",
      "mainTask": "Main learning objective for the day",
      "explanation": "Why this day matters and what you'll accomplish",
      "howTo": ["Step 1", "Step 2", "Step 3", "Step 4", "Step 5"],
      "checklist": ["Item needed 1", "Item needed 2", "Item needed 3", "Item needed 4", "Item needed 5"],
      "tips": ["Helpful tip 1", "Helpful tip 2", "Helpful tip 3"],
      "commonMistakes": ["Common mistake 1", "Common mistake 2", "Common mistake 3"],
      "estimatedTime": "${timeAvailable}",
      "skillLevel": "${experience}"
    }
  ]
}

Make each day build progressively on the previous day. Include practical, actionable steps.`;

    const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 4000,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices[0]?.message?.content;
    
    if (!content) {
      throw new Error('No content in API response');
    }

    const aiPlan = JSON.parse(content);
    
    // Add YouTube API videos to each day with quality filtering
    aiPlan.days = await Promise.all(aiPlan.days.map(async (day: any, index: number) => {
      // Use YouTube API for quality video selection
      const targetedVideoId = await getBestVideoForDay(
        hobby, 
        experience, 
        day.day, 
        day.title, 
        day.mainTask
      );
      
      const videoDetails = getVideoDetails(hobby, experience, day.day);
      
      return {
        ...day,
        // Ensure commonMistakes field exists (AI may use different field names)
        commonMistakes: day.commonMistakes || day.mistakesToAvoid || [
          `Rushing through exercises without understanding concepts`,
          `Skipping practice time or cutting sessions short`,
          `Not taking notes or tracking your improvement`
        ],
        youtubeVideoId: targetedVideoId,
        videoTitle: videoDetails?.title || `${day.title} - ${hobby} Tutorial`,
        freeResources: [{
          title: videoDetails?.title || `${day.title} Tutorial`,
          link: `https://youtube.com/watch?v=${targetedVideoId}`
        }],
        affiliateProducts: [{
          title: `${hobby} Essential Kit`,
          link: `https://amazon.com/dp/B${index + 1}234?tag=wizqo-20`,
          price: `$${19 + index * 5}.99`
        }]
      };
    }));

    // Ensure hobby field and correct difficulty mapping are included in the response
    aiPlan.hobby = hobby;
    aiPlan.difficulty = experience === 'some' ? 'intermediate' : experience;
    aiPlan.overview = aiPlan.overview || aiPlan.description || `A comprehensive ${hobby} learning plan tailored for ${experience === 'some' ? 'intermediate' : experience} learners`;
    
    // Force professional title format if AI generated old format
    if (aiPlan.title && aiPlan.title.includes('Learning Journey')) {
      aiPlan.title = `Master ${hobby.charAt(0).toUpperCase() + hobby.slice(1)} in 7 Days`;
    }
    
    return aiPlan;

  } catch (error) {
    console.error('DeepSeek API error:', error);
    console.log('⚠️ DeepSeek API failed, using fallback plan generation');
    return generateFallbackPlan(hobby, experience, timeAvailable, goal);
  }
}

// Fallback plan generator with YouTube API integration
async function generateFallbackPlan(hobby: string, experience: string, timeAvailable: string, goal: string) {
  const days = [];
  
  // Define unique daily topics and progressions
  const dailyTopics = [
    { focus: 'Basics & Setup', task: 'Get familiar with fundamentals and set up your practice space', skills: 'basic concepts and terminology' },
    { focus: 'Core Techniques', task: 'Master the essential techniques that form the foundation', skills: 'core techniques and proper form' },
    { focus: 'Building Skills', task: 'Develop coordination and muscle memory through practice', skills: 'coordination and skill-building exercises' },
    { focus: 'Practical Application', task: 'Apply what you\'ve learned in real-world scenarios', skills: 'practical application and problem-solving' },
    { focus: 'Advanced Elements', task: 'Introduce more challenging concepts and variations', skills: 'advanced techniques and variations' },
    { focus: 'Creative Expression', task: 'Explore creativity and personal style in your practice', skills: 'creative expression and personal style' },
    { focus: 'Integration & Mastery', task: 'Combine all elements and plan your continued journey', skills: 'integration and long-term planning' }
  ];

  const dailyMistakes = [
    ['Rushing through setup without proper preparation', 'Skipping basic safety or preparation steps', 'Not taking time to understand the fundamentals'],
    ['Using incorrect technique from the start', 'Practicing bad habits that are hard to break later', 'Ignoring proper form for speed'],
    ['Practicing without focus or clear goals', 'Not breaking down complex movements into parts', 'Expecting immediate perfection'],
    ['Not applying skills to real situations', 'Staying too comfortable with easy exercises', 'Avoiding challenging but important practice'],
    ['Attempting advanced techniques without mastering basics', 'Getting frustrated with increased difficulty', 'Skipping important foundational steps'],
    ['Copying others instead of finding your own style', 'Being too critical of creative attempts', 'Not exploring different approaches'],
    ['Not planning for continued learning', 'Thinking the journey ends after 7 days', 'Not celebrating progress made']
  ];

  const dailyTips = [
    ['Take time to properly set up your practice space', 'Focus on understanding why, not just how', 'Start slow and build confidence gradually'],
    ['Quality practice beats quantity every time', 'Focus on proper technique before speed', 'Use a mirror or recording to check your form'],
    ['Break complex skills into smaller parts', 'Celebrate small improvements each day', 'Be patient with your learning process'],
    ['Practice in different situations and environments', 'Challenge yourself with real-world applications', 'Don\'t be afraid to make mistakes'],
    ['Master the basics before moving to advanced techniques', 'Push your comfort zone but stay safe', 'Ask for feedback from experienced practitioners'],
    ['Experiment and find what feels natural to you', 'Draw inspiration from various sources', 'Trust your instincts and creative impulses'],
    ['Reflect on how far you\'ve come in just one week', 'Set realistic goals for continued growth', 'Connect with others who share your interest']
  ];
  
  for (let i = 0; i < 7; i++) {
    const dayNumber = i + 1;
    const dayTopic = dailyTopics[i];
    const dayTitle = `${hobby.charAt(0).toUpperCase() + hobby.slice(1)} ${dayTopic.focus} - ${dayNumber}`;
    
    // Use YouTube API for quality video selection
    const targetedVideoId = await getBestVideoForDay(
      hobby, 
      experience, 
      dayNumber, 
      dayTitle, 
      `${dayTopic.task} - Day ${dayNumber}`
    );
    const videoDetails = getVideoDetails(hobby, experience, dayNumber);
    
    days.push({
      day: dayNumber,
      title: dayTitle,
      mainTask: `${dayTopic.task} with focused practice and hands-on learning.`,
      explanation: `Day ${dayNumber} focuses on ${dayTopic.focus.toLowerCase()} in ${hobby}. You'll work on ${dayTopic.skills} while building on everything you've learned so far.`,
      howTo: [
        `Begin with ${dayTopic.skills} fundamentals`,
        `Practice the day's core techniques step-by-step`,
        `Complete ${dayNumber <= 3 ? 'foundational' : dayNumber <= 5 ? 'intermediate' : 'advanced'} exercises for ${experience} level`,
        `Apply today's skills in practical ${hobby} scenarios`,
        `Review progress and prepare for tomorrow's challenges`
      ],
      checklist: [
        `${hobby.charAt(0).toUpperCase() + hobby.slice(1)} equipment ready and organized`,
        `Practice area set up for ${dayTopic.focus.toLowerCase()} work`,
        `${dayNumber <= 3 ? 'Basic reference materials' : dayNumber <= 5 ? 'Intermediate guides' : 'Advanced resources'} available`,
        `Timer set for focused ${dayTopic.focus.toLowerCase()} practice`,
        `Progress tracking system ready for Day ${dayNumber}`
      ],
      tips: dailyTips[i],
      commonMistakes: dailyMistakes[i],
      freeResources: [{
        title: videoDetails?.title || `${hobby} ${dayTopic.focus} - ${dayNumber}`,
        link: `https://youtube.com/watch?v=${targetedVideoId}`
      }],
      affiliateProducts: [{
        title: `${hobby.charAt(0).toUpperCase() + hobby.slice(1)} ${dayNumber <= 3 ? 'Beginner' : dayNumber <= 5 ? 'Intermediate' : 'Advanced'} Kit`,
        link: `https://amazon.com/dp/B${dayNumber}${i + 2}34?tag=wizqo-20`
      }],
      youtubeVideoId: targetedVideoId,
      videoTitle: videoDetails?.title || `${hobby} - ${dayNumber}`,
      estimatedTime: timeAvailable,
      skillLevel: experience
    });
  }

  const plan = {
    hobby: hobby,
    title: `Master ${hobby.charAt(0).toUpperCase() + hobby.slice(1)} in 7 Days`,
    overview: `A comprehensive ${hobby} learning plan tailored for ${experience === 'some' ? 'intermediate' : experience} learners`,
    difficulty: experience === 'some' ? 'intermediate' : experience,
    totalDays: 7,
    days: days
  };
  
  console.log('🔍 FALLBACK PLAN GENERATED - First day commonMistakes:', plan.days[0].commonMistakes);
  console.log('🔍 FALLBACK PLAN GENERATED - First day youtubeVideoId:', plan.days[0].youtubeVideoId);
  console.log('🔍 FALLBACK PLAN DIFFICULTY:', plan.difficulty, 'EXPERIENCE:', experience);
  
  return plan;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Generate hobby plan endpoint with validation
  app.post('/api/generate-plan', async (req, res) => {
    try {
      const { hobby, experience, timeAvailable, goal } = req.body;
      
      if (!hobby || !experience || !timeAvailable) {
        return res.status(400).json({ 
          error: 'Missing required fields: hobby, experience, timeAvailable' 
        });
      }

      // Validate hobby input
      const validation = validateHobby(hobby);
      if (!validation.isValid) {
        const suggestions = suggestAlternativeHobbies(hobby);
        return res.status(400).json({
          error: `I didn't quite catch that hobby. Could you be more specific?`,
          suggestions: suggestions,
          message: `Try something like: ${suggestions.slice(0, 3).join(', ')}`
        });
      }
      
      const normalizedHobby = validation.normalizedHobby;
      const plan = await generateAIPlan(normalizedHobby, experience, timeAvailable, goal || `Learn ${normalizedHobby} fundamentals`);
      res.json(plan);
    } catch (error) {
      console.error('Error generating plan:', error);
      res.status(500).json({ error: 'Failed to generate learning plan' });
    }
  });

  // Database-backed hobby plans endpoints
  app.get('/api/hobby-plans/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      console.log('📖 API: Fetching hobby plans for user:', userId);
      
      const plans = await storage.getHobbyPlans(userId);
      console.log('📖 API: Found', plans.length, 'plans');
      res.json(plans);
    } catch (error) {
      console.error('📖 API: Error fetching hobby plans:', error);
      res.status(500).json({ error: 'Failed to fetch hobby plans' });
    }
  });

  app.post('/api/hobby-plans', async (req, res) => {
    try {
      const { user_id, hobby, title, overview, plan_data } = req.body;
      console.log('📝 DATABASE: Creating hobby plan for user:', user_id, 'hobby:', hobby);
      console.log('🔍 DEBUG: Plan data being saved - first day commonMistakes:', plan_data?.days?.[0]?.commonMistakes);
      console.log('🔍 DEBUG: Plan data being saved - first day youtubeVideoId:', plan_data?.days?.[0]?.youtubeVideoId);
      
      // Validate the request data
      const validatedData = insertHobbyPlanSchema.parse({
        userId: user_id,
        hobby,
        title,
        overview,
        planData: plan_data
      });
      
      const plan = await storage.createHobbyPlan(validatedData);
      console.log('📝 DATABASE: Created plan with ID:', plan.id);
      res.json(plan);
    } catch (error) {
      console.error('📝 API: Error creating hobby plan:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: 'Invalid request data', details: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create hobby plan' });
      }
    }
  });

  // User progress tracking endpoints
  app.get('/api/user-progress/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      console.log('📖 API: Fetching user progress for:', userId);
      
      const progress = await storage.getUserProgress(userId);
      console.log('📖 API: Found', progress.length, 'progress entries');
      res.json(progress);
    } catch (error) {
      console.error('📖 API: Error fetching user progress:', error);
      res.status(500).json({ error: 'Failed to fetch user progress' });
    }
  });

  app.post('/api/user-progress', async (req, res) => {
    try {
      const { user_id, plan_id, completed_days, current_day, unlocked_days } = req.body;
      console.log('📝 DATABASE: Creating/updating user progress for:', user_id, 'plan:', plan_id);
      
      // Validate the request data
      const validatedData = insertUserProgressSchema.parse({
        userId: user_id,
        planId: plan_id,
        completedDays: completed_days,
        currentDay: current_day,
        unlockedDays: unlocked_days
      });
      
      const progress = await storage.createOrUpdateUserProgress(validatedData);
      console.log('📝 DATABASE: Updated progress for plan:', plan_id);
      res.json(progress);
    } catch (error) {
      console.error('📝 API: Error updating user progress:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: 'Invalid request data', details: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to update user progress' });
      }
    }
  });

  // Contact form endpoint
  app.post('/api/contact', async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;
      
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ 
          error: 'All fields are required: name, email, subject, message' 
        });
      }

      const emailSent = await sendContactEmail({ name, email, subject, message });
      
      if (emailSent) {
        res.json({ success: true, message: 'Message sent successfully!' });
      } else {
        res.status(500).json({ error: 'Failed to send message. Please try again.' });
      }
    } catch (error: any) {
      console.error('Contact form error:', error);
      res.status(500).json({ error: 'Server error. Please try again later.' });
    }
  });

  const server = createServer(app);
  return server;
}