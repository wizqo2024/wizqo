import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Separator } from "./ui/separator";
import { YouTubeEmbed } from "./YouTubeEmbed";
import { LoginModal } from "./LoginModal";
import {
  CheckCircle,
  Lock,
  Play,
  ArrowRight,
  Trophy,
  Star,
  Clock,
  Target,
} from "lucide-react";

interface DayPlan {
  day: number;
  title: string;
  mainTask: string;
  explanation: string;
  howToGuide: string;
  checklist: string[];
  commonMistakes: string[];
  tips: string[];
  freeResource: {
    title: string;
    url: string;
  };
  affiliateLink: {
    title: string;
    url: string;
    store: "Amazon" | "Michaels";
  };
  videoId?: string;
}

interface PlanData {
  hobby: string;
  overview: string;
  days: DayPlan[];
}

interface UserProgress {
  completedDays: number[];
  currentDay: number;
  unlockedDays: number[];
}

interface PlanDisplayProps {
  planData: PlanData;
  onLogin: () => void;
  isLoggedIn: boolean;
  userProgress: UserProgress;
  onCompleteDay: (dayNumber: number) => void;
  isDayUnlocked: (dayNumber: number) => boolean;
  isDayCompleted: (dayNumber: number) => boolean;
  showLoginAfterDay1: boolean;
  onDismissLoginPrompt: () => void;
}

export function PlanDisplay({
  planData,
  onLogin,
  isLoggedIn,
  userProgress,
  onCompleteDay,
  isDayUnlocked,
  isDayCompleted,
  showLoginAfterDay1,
  onDismissLoginPrompt,
}: PlanDisplayProps) {
  const [currentView, setCurrentView] = useState<
    "summary" | number
  >("summary");
  const [showLoginModal, setShowLoginModal] = useState(false);

  // Show login modal after Day 1 completion
  useEffect(() => {
    if (showLoginAfterDay1) {
      setShowLoginModal(true);
    }
  }, [showLoginAfterDay1]);

  const handleLogin = () => {
    onLogin();
    setShowLoginModal(false);
    onDismissLoginPrompt();
  };

  const handleDismissLogin = () => {
    setShowLoginModal(false);
    onDismissLoginPrompt();
  };

  const handleDayClick = (dayNumber: number) => {
    if (isDayUnlocked(dayNumber)) {
      setCurrentView(dayNumber);
    } else if (!isLoggedIn && dayNumber > 1) {
      setShowLoginModal(true);
    }
  };

  const handleCompleteDay = (dayNumber: number) => {
    onCompleteDay(dayNumber);

    // Navigate to next day if available and unlocked
    const nextDay = dayNumber + 1;
    if (nextDay <= 7 && isDayUnlocked(nextDay)) {
      setCurrentView(nextDay);
    } else if (dayNumber === 7) {
      // Show completion celebration
      setCurrentView("summary");
    }
  };

  const getProgressPercentage = () => {
    return (userProgress.completedDays.length / 7) * 100;
  };

  const renderSummary = () => (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center p-3 bg-gradient-primary rounded-full mb-4 shadow-colorful">
          <Trophy className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-semibold text-foreground">
          {planData.hobby} in 7 Days
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          {planData.overview}
        </p>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">
              Your Progress
            </span>
            <span className="text-primary font-medium">
              {userProgress.completedDays.length}/7 days
              completed
            </span>
          </div>
          <Progress
            value={getProgressPercentage()}
            className="h-3"
          />
        </div>

        {/* Status Badge */}
        {userProgress.completedDays.length === 7 ? (
          <Badge className="bg-gradient-success text-white px-4 py-2">
            🎉 Congratulations! Plan Completed!
          </Badge>
        ) : (
          <Badge variant="outline" className="px-4 py-2">
            📚 {7 - userProgress.completedDays.length} days
            remaining
          </Badge>
        )}
      </div>

      {/* Day Overview Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {planData.days.map((day) => {
          const isUnlocked = isDayUnlocked(day.day);
          const isCompleted = isDayCompleted(day.day);
          const isCurrent =
            userProgress.currentDay === day.day && !isCompleted;

          return (
            <Card
              key={day.day}
              className={`relative transition-all duration-200 ${
                isUnlocked
                  ? "hover-lift border-gradient cursor-pointer-override"
                  : "opacity-60 cursor-default"
              } ${isCurrent ? "ring-2 ring-primary/50" : ""} ${
                isCompleted
                  ? "bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20"
                  : ""
              }`}
              onClick={() => handleDayClick(day.day)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <Badge
                    variant={
                      isCompleted ? "default" : "outline"
                    }
                    className={`${isCompleted ? "bg-gradient-success text-white" : ""}`}
                  >
                    Day {day.day}
                  </Badge>

                  {/* Status Icon */}
                  <div className="flex items-center">
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : !isUnlocked ? (
                      <Lock className="w-5 h-5 text-muted-foreground" />
                    ) : isCurrent ? (
                      <Play className="w-5 h-5 text-primary" />
                    ) : (
                      <Clock className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>
                </div>

                <CardTitle className="text-lg">
                  {day.title}
                </CardTitle>
                <CardDescription className="line-clamp-2">
                  {day.explanation}
                </CardDescription>
              </CardHeader>

              <CardContent className="pt-0">
                {!isUnlocked && day.day > 1 && (
                  <div className="text-center py-4">
                    <Lock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {!isLoggedIn
                        ? "Sign in to unlock"
                        : "Complete previous days first"}
                    </p>
                  </div>
                )}

                {isUnlocked && (
                  <Button
                    variant={isCurrent ? "default" : "outline"}
                    size="sm"
                    className={`w-full ${isCurrent ? "bg-gradient-primary cursor-pointer-override" : "cursor-pointer-override"}`}
                  >
                    {isCompleted
                      ? "Review Day"
                      : isCurrent
                        ? "Continue"
                        : "Start Day"}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Call to Action */}
      {userProgress.completedDays.length === 0 && (
        <div className="text-center py-8 space-y-4">
          <div className="space-y-2">
            <h3 className="text-xl font-semibold">
              Ready to Start Your Journey?
            </h3>
            <p className="text-muted-foreground">
              Day 1 is completely free - no account required!
            </p>
          </div>

          <Button
            size="lg"
            className="bg-gradient-primary hover:opacity-90 cursor-pointer-override"
            onClick={() => handleDayClick(1)}
          >
            <Target className="w-5 h-5 mr-2" />
            Start Day 1 - Free
          </Button>
        </div>
      )}

      {/* Login Prompt for Day 2+ */}
      {!isLoggedIn &&
        userProgress.completedDays.includes(1) && (
          <Card className="border-gradient bg-gradient-to-br from-primary/5 to-secondary/5">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                Unlock Your Full Learning Journey
              </CardTitle>
              <CardDescription>
                Great job completing Day 1! Sign in to track
                your progress and unlock Days 2-7.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button
                size="lg"
                className="bg-gradient-primary hover:opacity-90 cursor-pointer-override"
                onClick={() => setShowLoginModal(true)}
              >
                Sign In to Continue
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        )}
    </div>
  );

  const renderDay = (dayNumber: number) => {
    const day = planData.days.find((d) => d.day === dayNumber);
    if (!day) return null;

    const isUnlocked = isDayUnlocked(dayNumber);
    const isCompleted = isDayCompleted(dayNumber);

    if (!isUnlocked) {
      return (
        <div className="max-w-4xl mx-auto text-center py-16 space-y-6">
          <div className="inline-flex items-center justify-center p-4 bg-muted rounded-full mb-4">
            <Lock className="w-12 h-12 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-semibold">
            Day {dayNumber} is Locked
          </h2>
          <p className="text-muted-foreground text-lg max-w-md mx-auto">
            {!isLoggedIn && dayNumber > 1
              ? "Sign in to track your progress and unlock this day."
              : "Complete the previous days to unlock this lesson."}
          </p>

          {!isLoggedIn && dayNumber > 1 && (
            <Button
              size="lg"
              className="bg-gradient-primary hover:opacity-90 cursor-pointer-override"
              onClick={() => setShowLoginModal(true)}
            >
              Sign In to Unlock
            </Button>
          )}

          <Button
            variant="outline"
            onClick={() => setCurrentView("summary")}
            className="cursor-pointer-override"
          >
            Back to Overview
          </Button>
        </div>
      );
    }

    return (
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Day Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-4">
            <Badge className="bg-gradient-primary text-white px-4 py-2">
              Day {day.day} of 7
            </Badge>
            {isCompleted && (
              <Badge className="bg-gradient-success text-white px-3 py-1">
                ✓ Completed
              </Badge>
            )}
          </div>
          <h1 className="text-3xl font-semibold">
            {day.title}
          </h1>

          {/* Progress indicator */}
          <div className="text-sm text-muted-foreground">
            Progress: {userProgress.completedDays.length}/7 days
            completed
          </div>
        </div>

        {/* Main Content */}
        <div className="grid gap-8">
          {/* Main Task */}
          <Card className="border-gradient">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-xl">🎯</span> Main Task
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg leading-relaxed">
                {day.mainTask}
              </p>
            </CardContent>
          </Card>

          {/* Explanation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-xl">📚</span> Explanation
                &amp; Why
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="leading-relaxed">
                {day.explanation}
              </p>
            </CardContent>
          </Card>

          {/* How-to Guide */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="text-xl">🔍</span> How to Guide
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="leading-relaxed">
                {day.howToGuide}
              </p>
            </CardContent>
          </Card>

          {/* Checklist */}
          {day.checklist.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-xl">📋</span> Checklist
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {day.checklist.map((item, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-3"
                    >
                      <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Common Mistakes */}
          {day.commonMistakes.length > 0 && (
            <Card className="border-red-200 dark:border-red-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-400">
                  <span className="text-xl">⚠️</span> Common
                  Mistakes to Avoid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {day.commonMistakes.map((mistake, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-3"
                    >
                      <span className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></span>
                      <span className="text-red-700 dark:text-red-300">
                        {mistake}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Tips */}
          {day.tips.length > 0 && (
            <Card className="border-green-200 dark:border-green-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-700 dark:text-green-400">
                  <span className="text-xl">💡</span> Tips for
                  Success
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {day.tips.map((tip, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-3"
                    >
                      <span className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></span>
                      <span className="text-green-700 dark:text-green-300">
                        {tip}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* YouTube Video */}
          {day.videoId && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-xl">🎥</span> Tutorial
                  Video
                </CardTitle>
                <CardDescription>
                  Follow along with this step-by-step video
                  tutorial
                </CardDescription>
              </CardHeader>
              <CardContent>
                <YouTubeEmbed
                  videoId={day.videoId}
                  title={day.freeResource.title}
                />
              </CardContent>
            </Card>
          )}

          {/* Resources */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Free Resource */}
            <Card className="border-blue-200 dark:border-blue-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
                  <span className="text-xl">🔗</span> Free
                  Resource
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-3">{day.freeResource.title}</p>
                <Button
                  variant="outline"
                  className="w-full cursor-pointer-override border-blue-200 text-blue-700 hover:bg-blue-50 dark:border-blue-800 dark:text-blue-400 dark:hover:bg-blue-900/20"
                  onClick={() =>
                    window.open(day.freeResource.url, "_blank")
                  }
                >
                  Access Free Resource ↗
                </Button>
              </CardContent>
            </Card>

            {/* Affiliate Resource */}
            <Card className="border-orange-200 dark:border-orange-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-700 dark:text-orange-400">
                  <span className="text-xl">🛒</span>{" "}
                  Recommended Tool
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-3">
                  {day.affiliateLink.title}
                </p>
                <div className="flex items-center gap-2 mb-3">
                  <Badge
                    variant="outline"
                    className="text-orange-700 border-orange-200 dark:text-orange-400 dark:border-orange-800"
                  >
                    {day.affiliateLink.store}
                  </Badge>
                </div>
                <Button
                  variant="outline"
                  className="w-full cursor-pointer-override border-orange-200 text-orange-700 hover:bg-orange-50 dark:border-orange-800 dark:text-orange-400 dark:hover:bg-orange-900/20"
                  onClick={() =>
                    window.open(day.affiliateLink.url, "_blank")
                  }
                >
                  View on {day.affiliateLink.store} ↗
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Completion Section */}
          <Card className="border-gradient bg-gradient-to-br from-primary/5 to-secondary/5">
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-semibold">
                  Ready to Complete Day {day.day}?
                </h3>
                <p className="text-muted-foreground">
                  Mark this day as complete when you've finished
                  the main task and feel confident with the
                  concepts.
                </p>

                <div className="flex gap-4 justify-center">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentView("summary")}
                    className="cursor-pointer-override"
                  >
                    Back to Overview
                  </Button>

                  {!isCompleted ? (
                    <Button
                      size="lg"
                      className="bg-gradient-success hover:opacity-90 cursor-pointer-override"
                      onClick={() => handleCompleteDay(day.day)}
                    >
                      <CheckCircle className="w-5 h-5 mr-2" />
                      Complete Day {day.day}
                    </Button>
                  ) : (
                    <Badge className="bg-gradient-success text-white px-6 py-3 text-base">
                      ✓ Day {day.day} Completed!
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-8">
        {/* Navigation */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-6">
            {currentView !== "summary" && (
              <Button
                variant="outline"
                onClick={() => setCurrentView("summary")}
                className="cursor-pointer-override"
              >
                ← Overview
              </Button>
            )}

            {/* Day Navigation */}
            {currentView !== "summary" && (
              <div className="flex items-center gap-2">
                {planData.days.map((day) => (
                  <Button
                    key={day.day}
                    variant={
                      currentView === day.day
                        ? "default"
                        : "outline"
                    }
                    size="sm"
                    onClick={() => handleDayClick(day.day)}
                    disabled={!isDayUnlocked(day.day)}
                    className={`cursor-pointer-override ${
                      isDayCompleted(day.day)
                        ? "bg-gradient-success"
                        : ""
                    } ${
                      !isDayUnlocked(day.day)
                        ? "opacity-50 cursor-not-allowed"
                        : ""
                    }`}
                  >
                    {isDayCompleted(day.day) ? "✓" : day.day}
                  </Button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Content */}
        {currentView === "summary"
          ? renderSummary()
          : renderDay(currentView)}
      </div>

      {/* Login Modal */}
      <LoginModal
        isOpen={showLoginModal}
        onClose={handleDismissLogin}
        onLogin={handleLogin}
        showRemindLater={true}
        title="Continue Your Learning Journey"
        description="Sign in to track your progress and unlock all 7 days of your personalized learning plan."
      />
    </div>
  );
}