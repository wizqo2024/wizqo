import React from 'react';
import { Button } from './ui/button';
import { ArrowLeft, Home, User, Settings } from 'lucide-react';

interface NavigationProps {
  onBack: () => void;
  planTitle: string;
}

export function Navigation({ onBack, planTitle }: NavigationProps) {
  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50 backdrop-blur-sm bg-card/80">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Left side - Back button and title */}
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onBack}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <div className="hidden md:block h-6 w-px bg-border"></div>
            <div className="text-sm">
              <span className="text-muted-foreground">Learning:</span>
              <span className="ml-2 font-medium">{planTitle}</span>
            </div>
          </div>

          {/* Center - Wizqo logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
              <span className="text-white text-sm font-bold">W</span>
            </div>
            <span className="font-bold text-lg">Wizqo</span>
          </div>

          {/* Right side - Navigation items */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Home className="h-4 w-4" />
              <span className="hidden md:inline ml-2">Home</span>
            </Button>
            <Button variant="ghost" size="sm">
              <User className="h-4 w-4" />
              <span className="hidden md:inline ml-2">Profile</span>
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
              <span className="hidden md:inline ml-2">Settings</span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}