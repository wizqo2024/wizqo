import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ArrowRight, Sparkles, Target, Clock, Trophy, Users, Star, Zap } from 'lucide-react';

interface LandingPageProps {
  onStartPlan: () => void;
}

export function LandingPage({ onStartPlan }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 overflow-hidden">
      {/* Hero Section */}
      <div className="relative">
        {/* Navigation */}
        <nav className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-semibold text-gradient-primary">Wizqo</span>
            </div>
            
            <div className="hidden md:flex items-center gap-6">
              <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">Features</a>
              <a href="#how-it-works" className="text-muted-foreground hover:text-foreground transition-colors">How It Works</a>
              <a href="#testimonials" className="text-muted-foreground hover:text-foreground transition-colors">Reviews</a>
              <Button variant="outline" size="sm" className="cursor-pointer-override">Sign In</Button>
            </div>
          </div>
        </nav>

        {/* Hero Content */}
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Badge */}
            <Badge variant="secondary" className="bg-gradient-primary text-white px-4 py-2 text-sm">
              🚀 New: AI-Powered Learning Plans
            </Badge>
            
            {/* Main Headline */}
            <h1 className="text-colorful-primary max-w-4xl mx-auto leading-tight">
              Master Any Hobby in Just 7 Days with AI-Powered Learning Plans
            </h1>
            
            {/* Subheadline */}
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              From painting to coding, cooking to photography - get personalized daily lessons, expert tips, and step-by-step guidance tailored to your schedule and goals.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <Button 
                size="lg" 
                className="bg-gradient-primary hover:opacity-90 text-lg px-8 py-6 gap-2 shadow-colorful cursor-pointer-override"
                onClick={onStartPlan}
              >
                <Target className="w-5 h-5" />
                Start Learning Today
                <ArrowRight className="w-5 h-5" />
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                className="text-lg px-8 py-6 bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 cursor-pointer-override"
              >
                Watch Demo
              </Button>
            </div>
            
            {/* Trust Indicators */}
            <div className="flex items-center justify-center gap-8 pt-8 flex-wrap">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="w-4 h-4 text-green-500" />
                <span>10,000+ learners</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Star className="w-4 h-4 text-yellow-500" />
                <span>4.9/5 rating</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Zap className="w-4 h-4 text-blue-500" />
                <span>100% Free</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div id="features" className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-semibold mb-4">Why Choose Wizqo?</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Our AI creates learning plans that actually work - structured, personalized, and designed for real results.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="border-gradient bg-gradient-to-br from-card/90 to-card/70 backdrop-blur-xl hover-lift">
            <CardHeader>
              <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center mb-4">
                <Target className="w-6 h-6 text-white" />
              </div>
              <CardTitle>Personalized Plans</CardTitle>
              <CardDescription>
                Every plan is tailored to your experience level, available time, and specific goals.
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card className="border-gradient bg-gradient-to-br from-card/90 to-card/70 backdrop-blur-xl hover-lift">
            <CardHeader>
              <div className="w-12 h-12 bg-gradient-success rounded-full flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <CardTitle>7-Day Structure</CardTitle>
              <CardDescription>
                Proven methodology that takes you from beginner to confident in just one week.
              </CardDescription>
            </CardHeader>
          </Card>
          
          <Card className="border-gradient bg-gradient-to-br from-card/90 to-card/70 backdrop-blur-xl hover-lift">
            <CardHeader>
              <div className="w-12 h-12 bg-gradient-warning rounded-full flex items-center justify-center mb-4">
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <CardTitle>Real Results</CardTitle>
              <CardDescription>
                Complete projects, build skills, and create something you're proud to show off.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>

      {/* How It Works Section */}
      <div id="how-it-works" className="bg-muted/30 backdrop-blur-sm py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-semibold mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg">
              Get started in less than 60 seconds
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl text-white font-bold">1</span>
              </div>
              <h3 className="text-xl font-semibold">Choose Your Hobby</h3>
              <p className="text-muted-foreground">
                Tell us what you want to learn or let our AI surprise you with something new.
              </p>
            </div>
            
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-success rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl text-white font-bold">2</span>
              </div>
              <h3 className="text-xl font-semibold">Answer 3 Questions</h3>
              <p className="text-muted-foreground">
                Quick questions about your experience, time, and goals to personalize your plan.
              </p>
            </div>
            
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-warning rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl text-white font-bold">3</span>
              </div>
              <h3 className="text-xl font-semibold">Start Learning</h3>
              <p className="text-muted-foreground">
                Follow your personalized 7-day plan with daily tasks, tips, and video tutorials.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-2xl mx-auto space-y-6">
          <h2 className="text-3xl font-semibold">Ready to Start Learning?</h2>
          <p className="text-xl text-muted-foreground">
            Join thousands of learners who have mastered new skills with Wizqo's AI-powered plans.
          </p>
          
          <Button 
            size="lg" 
            className="bg-gradient-primary hover:opacity-90 text-lg px-8 py-6 gap-2 shadow-colorful cursor-pointer-override"
            onClick={onStartPlan}
          >
            <Target className="w-5 h-5" />
            Generate My Learning Plan
            <ArrowRight className="w-5 h-5" />
          </Button>
          
          <p className="text-sm text-muted-foreground">
            No credit card required • 100% free • Start immediately
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-muted/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-gradient-primary rounded-full flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-white" />
              </div>
              <span className="font-semibold text-gradient-primary">Wizqo</span>
            </div>
            
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors cursor-pointer-override">Privacy</a>
              <a href="#" className="hover:text-foreground transition-colors cursor-pointer-override">Terms</a>
              <a href="#" className="hover:text-foreground transition-colors cursor-pointer-override">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}