import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Loader2, Send, Sparkles } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  options?: string[];
}

interface QuizAnswers {
  experience: string;
  timeAvailable: string;
  goal: string;
}

interface ChatInterfaceProps {
  onPlanGenerate: (hobby: string, answers: QuizAnswers) => void;
}

export function ChatInterface({ onPlanGenerate }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hi! Tell me your hobby to begin your personalized journey.",
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [currentStep, setCurrentStep] = useState<'hobby' | 'quiz' | 'generating'>('hobby');
  const [hobby, setHobby] = useState('');
  const [quizStep, setQuizStep] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<QuizAnswers>({
    experience: '',
    timeAvailable: '',
    goal: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const quizQuestions = [
    {
      question: "What's your experience level?",
      options: ["Beginner", "Intermediate", "Pro"],
      key: 'experience' as keyof QuizAnswers
    },
    {
      question: "How much time can you dedicate per day?",
      options: ["15-30 minutes", "30-60 minutes", "1-2 hours", "2+ hours"],
      key: 'timeAvailable' as keyof QuizAnswers
    },
    {
      question: "What's your main goal?",
      options: ["Stress relief", "Skill mastery", "Creative expression", "Social connection"],
      key: 'goal' as keyof QuizAnswers
    }
  ];

  // Default answers for "Surprise Me" option
  const getDefaultAnswers = (): QuizAnswers => ({
    experience: "Beginner",
    timeAvailable: "30-60 minutes",
    goal: "Creative expression"
  });

  const addMessage = (content: string, type: 'user' | 'bot', options?: string[]) => {
    const newMessage: Message = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type,
      content,
      options
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const handleHobbySubmit = () => {
    if (!inputValue.trim()) {
      addMessage("Let's try a specific hobby (like painting, gardening, coding) to get started!", 'bot');
      return;
    }

    const hobbyInput = inputValue.toLowerCase().trim();
    
    // Handle multiple hobbies
    if (hobbyInput.includes(' and ') || hobbyInput.includes(',')) {
      addMessage(inputValue, 'user');
      addMessage("Looks like you mentioned more than one hobby. Want to focus on just one for now?", 'bot', [
        "🎨 Start with the first one",
        "🎲 Surprise me!",
        "🔁 Let me choose a different hobby"
      ]);
      return;
    }

    // Handle vague inputs
    if (['fun', 'something fun', 'anything'].includes(hobbyInput)) {
      addMessage(inputValue, 'user');
      addMessage("Do you mean arts, games, or outdoor fun?", 'bot', [
        "🎨 Arts",
        "🧩 Games", 
        "🌿 Nature",
        "🔧 DIY"
      ]);
      return;
    }

    // Handle typos
    const typoMap: { [key: string]: string } = {
      'panting': 'painting',
      'gardning': 'gardening',
      'photograpy': 'photography',
      'cookin': 'cooking'
    };

    if (typoMap[hobbyInput]) {
      addMessage(inputValue, 'user');
      addMessage(`Did you mean ${typoMap[hobbyInput]}?`, 'bot', [
        `Yes, ${typoMap[hobbyInput]}`,
        "No, let me try again"
      ]);
      return;
    }

    // Valid hobby
    addMessage(inputValue, 'user');
    setHobby(inputValue);
    setCurrentStep('quiz');
    startQuiz();
  };

  const startQuiz = () => {
    addMessage("Great! Just 3 quick questions to personalize your plan.", 'bot');
    setTimeout(() => {
      addMessage(quizQuestions[0].question, 'bot', quizQuestions[0].options);
    }, 1000);
  };

  const generateSurprisePlan = () => {
    const randomHobbies = [
      'painting', 'gardening', 'photography', 'cooking', 'coding', 
      'knitting', 'pottery', 'chess', 'guitar', 'writing', 
      'origami', 'calligraphy', 'woodworking', 'yoga', 'sketching'
    ];
    const randomHobby = randomHobbies[Math.floor(Math.random() * randomHobbies.length)];
    
    setCurrentStep('generating');
    setIsLoading(true);
    
    addMessage(`Perfect! I've chosen ${randomHobby} for you. Creating your beginner-friendly plan...`, 'bot');
    
    // Generate plan with default answers after a delay
    setTimeout(() => {
      onPlanGenerate(randomHobby, getDefaultAnswers());
    }, 2000);
  };

  const handleQuizAnswer = (answer: string) => {
    addMessage(answer, 'user');
    
    const currentQuestion = quizQuestions[quizStep];
    setQuizAnswers(prev => ({
      ...prev,
      [currentQuestion.key]: answer
    }));

    if (quizStep < quizQuestions.length - 1) {
      setQuizStep(prev => prev + 1);
      setTimeout(() => {
        const isLastQuestion = quizStep + 1 === quizQuestions.length - 1;
        addMessage(isLastQuestion ? "Perfect! Last question..." : "Great! Next question...", 'bot');
        setTimeout(() => {
          const nextQuestion = quizQuestions[quizStep + 1];
          addMessage(nextQuestion.question, 'bot', nextQuestion.options);
        }, 500);
      }, 1000);
    } else {
      // Quiz complete
      setTimeout(() => {
        addMessage(`Thanks! Generating your 7-day ${hobby} plan...`, 'bot');
        setCurrentStep('generating');
        setIsLoading(true);
        
        // Simulate API call
        setTimeout(() => {
          const finalAnswers = {
            ...quizAnswers,
            [currentQuestion.key]: answer
          };
          onPlanGenerate(hobby, finalAnswers);
        }, 2000);
      }, 1000);
    }
  };

  const handleOptionClick = (option: string) => {
    if (currentStep === 'hobby') {
      if (option.startsWith('🎨')) {
        setHobby('painting');
        setCurrentStep('quiz');
        addMessage(option, 'user');
        startQuiz();
      } else if (option.startsWith('🎲')) {
        addMessage(option, 'user');
        generateSurprisePlan();
      } else if (option.startsWith('🧩')) {
        setHobby('chess');
        setCurrentStep('quiz');
        addMessage(option, 'user');
        startQuiz();
      } else if (option.startsWith('🌿')) {
        setHobby('gardening');
        setCurrentStep('quiz');
        addMessage(option, 'user');
        startQuiz();
      } else if (option.startsWith('🔧')) {
        setHobby('woodworking');
        setCurrentStep('quiz');
        addMessage(option, 'user');
        startQuiz();
      }
    } else if (currentStep === 'quiz') {
      handleQuizAnswer(option);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (currentStep === 'hobby') {
        handleHobbySubmit();
        setInputValue('');
      }
    }
  };

  return (
    <div className="flex flex-col h-full max-w-2xl mx-auto">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <Card className={`max-w-[80%] ${
              message.type === 'user' 
                ? 'bg-primary text-primary-foreground' 
                : 'bg-card'
            }`}>
              <CardContent className="p-3">
                <p className="text-sm">{message.content}</p>
                {message.options && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {message.options.map((option, index) => (
                      <Button
                        key={`${message.id}-option-${index}`}
                        variant="outline"
                        size="sm"
                        onClick={() => handleOptionClick(option)}
                        className={`text-xs cursor-pointer-override ${
                          message.type === 'user' ? 'border-primary-foreground text-primary-foreground' : ''
                        }`}
                      >
                        {option}
                      </Button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <Card className="bg-card">
              <CardContent className="p-3 flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                <p className="text-sm">Crafting your plan...</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {currentStep === 'hobby' && !isLoading && (
        <div className="p-4 border-t bg-background">
          <div className="flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your hobby here..."
              className="flex-1"
            />
            <Button 
              onClick={handleHobbySubmit}
              disabled={!inputValue.trim()}
              className="cursor-pointer-override"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-2 mt-3">
            <Badge variant="secondary" className="cursor-pointer-override" onClick={() => setInputValue('painting')}>
              🎨 Arts
            </Badge>
            <Badge variant="secondary" className="cursor-pointer-override" onClick={() => setInputValue('chess')}>
              🧩 Games
            </Badge>
            <Badge variant="secondary" className="cursor-pointer-override" onClick={() => setInputValue('gardening')}>
              🌿 Nature
            </Badge>
            <Badge variant="secondary" className="cursor-pointer-override" onClick={() => setInputValue('woodworking')}>
              🔧 DIY
            </Badge>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={generateSurprisePlan}
              className="text-xs cursor-pointer-override"
            >
              <Sparkles className="h-3 w-3 mr-1" />
              Surprise Me
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}