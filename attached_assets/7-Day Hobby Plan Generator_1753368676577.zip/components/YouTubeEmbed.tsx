import React, { useState } from 'react';
import { Play, Volume2, VolumeX, Maximize, Minimize } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface YouTubeEmbedProps {
  videoId: string;
  title: string;
  autoplay?: boolean;
  showControls?: boolean;
  className?: string;
}

export function YouTubeEmbed({ 
  videoId, 
  title, 
  autoplay = false, 
  showControls = true,
  className = "" 
}: YouTubeEmbedProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showThumbnail, setShowThumbnail] = useState(true);

  // YouTube thumbnail URL
  const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
  
  // YouTube embed URL with parameters
  const embedUrl = `https://www.youtube.com/embed/${videoId}?${new URLSearchParams({
    autoplay: isPlaying ? '1' : '0',
    mute: isMuted ? '1' : '0',
    rel: '0', // Don't show related videos
    modestbranding: '1', // Minimal YouTube branding
    playsinline: '1', // Play inline on mobile
    enablejsapi: '1', // Enable JavaScript API
    origin: window.location.origin
  })}`;

  const handlePlayClick = () => {
    setIsPlaying(true);
    setShowThumbnail(false);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <div className={`relative w-full ${className}`}>
      {/* Video Container */}
      <div className={`relative bg-black rounded-xl overflow-hidden shadow-lg transition-all duration-300 ${
        isFullscreen 
          ? 'fixed inset-4 z-50 rounded-2xl' 
          : 'aspect-video'
      }`}>
        
        {/* Thumbnail Overlay */}
        {showThumbnail && (
          <div className="absolute inset-0 bg-black">
            <img 
              src={thumbnailUrl}
              alt={title}
              className="w-full h-full object-cover"
              onError={(e) => {
                // Fallback to default thumbnail if maxres not available
                const target = e.target as HTMLImageElement;
                target.src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
              }}
            />
            
            {/* Play Button Overlay */}
            <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm">
              <Button
                size="lg"
                onClick={handlePlayClick}
                className="w-20 h-20 rounded-full bg-gradient-primary hover:opacity-90 shadow-colorful transition-all duration-300 hover:scale-110"
              >
                <Play className="w-8 h-8 text-white ml-1" fill="currentColor" />
              </Button>
            </div>

            {/* Video Title Overlay */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <Badge variant="secondary" className="bg-white/20 text-white backdrop-blur-sm mb-2">
                📹 Tutorial Video
              </Badge>
              <h4 className="text-white font-medium text-sm md:text-base line-clamp-2">
                {title}
              </h4>
            </div>
          </div>
        )}

        {/* YouTube iframe */}
        {!showThumbnail && (
          <iframe
            src={embedUrl}
            title={title}
            className="w-full h-full"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            loading="lazy"
          />
        )}

        {/* Custom Controls Overlay */}
        {showControls && !showThumbnail && (
          <div className="absolute top-4 right-4 flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={toggleMute}
              className="bg-black/50 border-white/20 text-white hover:bg-black/70 backdrop-blur-sm"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={toggleFullscreen}
              className="bg-black/50 border-white/20 text-white hover:bg-black/70 backdrop-blur-sm"
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </Button>
          </div>
        )}
      </div>

      {/* Video Information */}
      <div className="mt-3 space-y-2">
        <div className="flex items-center justify-between">
          <Badge variant="outline" className="bg-gradient-primary text-white border-none">
            🎯 Day Tutorial
          </Badge>
          <a 
            href={`https://youtube.com/watch?v=${videoId}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-muted-foreground hover:text-primary transition-colors cursor-pointer"
          >
            Watch on YouTube ↗
          </a>
        </div>
        
        <p className="text-sm text-muted-foreground leading-relaxed">
          Follow along with this step-by-step tutorial designed specifically for your learning journey.
        </p>
      </div>

      {/* Fullscreen Close Button */}
      {isFullscreen && (
        <Button
          onClick={toggleFullscreen}
          className="fixed top-8 right-8 z-60 bg-black/70 text-white hover:bg-black/90 backdrop-blur-sm"
          size="sm"
        >
          <Minimize className="w-4 h-4 mr-2" />
          Exit Fullscreen
        </Button>
      )}
    </div>
  );
}