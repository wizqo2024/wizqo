# Wizqo Project Guidelines

## General Guidelines

* All interactive elements must have proper cursor styles (cursor: pointer for clickable elements)
* Only use absolute positioning when necessary. Opt for responsive and well structured layouts that use flexbox and grid by default
* Refactor code as you go to keep code clean
* Keep file sizes small and put helper functions and components in their own files
* Maintain 7-day learning plan structure consistently across all hobby plans
* Always use our enhanced prompt structure with all required sections (🎯 Main Task, 📚 Explanation & Why, etc.)

## Design System Guidelines

### Cursor & Interaction Guidelines
* All buttons must show `cursor: pointer` on hover
* Interactive cards and hover-lift elements must have pointer cursor
* Disabled elements should show `cursor: not-allowed`
* Text inputs should show `cursor: text`
* Links should always show `cursor: pointer`
* Use the `.cursor-pointer` utility class when needed to override defaults

### Typography
* Use a base font-size of 14px
* Never override font sizes, weights, or line heights unless specifically requested by user
* Use clamp() for responsive typography
* Maintain proper heading hierarchy (h1 > h2 > h3)

### Color System
* Primary gradient: `linear-gradient(135deg, #667eea 0%, #764ba2 100%)`
* Secondary gradient: `linear-gradient(135deg, #f093fb 0%, #f5576c 100%)`
* Success gradient: `linear-gradient(135deg, #4ade80 0%, #22c55e 100%)`
* Warning gradient: `linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)`
* Use `.text-gradient-primary` for colorful text effects

### Component Guidelines

#### Buttons
* Primary buttons should use `bg-gradient-primary` class
* All buttons must have `cursor: pointer` (handled by global CSS)
* Use `hover:opacity-90` for gradient button hover states
* Include proper focus states with `focus-visible:` variants
* Button sizes: sm, md (default), lg with consistent padding

#### Cards
* Use `.border-gradient` for enhanced card borders
* Apply `.hover-lift` for subtle elevation on hover
* Use `.glass-effect` for overlay/modal cards
* Include proper shadow levels with `.shadow-colorful`

#### YouTube Video Integration
* Use the enhanced YouTubeEmbed component with thumbnail previews
* Include proper loading states and error handling
* Maintain consistent video player styling with project design
* Add context information below videos (video description, "Watch on YouTube" link)
* Ensure mobile responsiveness with proper aspect ratios

### Animation Guidelines
* Use `will-change: transform` for elements that will animate
* Implement hardware acceleration with `transform: translateZ(0)`
* Respect `prefers-reduced-motion` for accessibility
* Keep animations smooth with 60fps performance
* Use easing functions: `ease-out` for entrances, `ease-in` for exits

### Mobile Optimization
* Mobile-first responsive design approach
* Reduce animation complexity on mobile devices
* Optimize backdrop-blur effects for mobile performance
* Ensure touch targets are minimum 44px for accessibility
* Test hover states work properly on touch devices

### Performance Guidelines
* Lazy load images and iframes with `loading="lazy"`
* Use `transform: translateZ(0)` for smooth animations
* Optimize backdrop-filter usage on mobile
* Minimize paint operations with proper CSS containment
* Use CSS custom properties for consistent theming

### Accessibility Guidelines
* Proper focus management with visible focus indicators
* Screen reader friendly semantic HTML structure
* Color contrast ratios meet WCAG standards
* Keyboard navigation support for all interactive elements
* Alt text for all images and meaningful content

### 7-Day Plan Structure
* Always maintain exactly 7 days in each plan
* Include all enhanced sections: 🎯 Main Task, 📚 Explanation & Why, 🔍 How to Guide, 📋 Checklist, ⚠️ Common Mistakes, 💡 Tips, 🔗 Free Resource, 🛒 Affiliate Link
* Progressive difficulty from Day 1 (absolute beginner) to Day 7 (first real project)
* Each day should align with user's specified time commitment
* Include YouTube video integration for each day
* Maintain consistent tone: encouraging, practical, beginner-friendly

## File Organization
* Components in `/components/` directory
* UI components in `/components/ui/` (shadcn only)
* Utilities in `/utils/` directory
* Styles in `/styles/globals.css` (single file approach)
* AI prompts and documentation in `/prompts/` directory