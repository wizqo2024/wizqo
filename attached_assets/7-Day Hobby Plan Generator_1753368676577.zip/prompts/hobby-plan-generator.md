# Enhanced DeepSeek API Prompt Template for Detailed 7-Day Hobby Plans

Use this enhanced prompt structure when calling the DeepSeek API for comprehensive learning plans:

```
Generate a detailed, motivating, and beginner-level-appropriate 7-day learning plan for the hobby: ${hobby}.

User Details:
- Experience level: ${experience}
- Time commitment per day: ${timeAvailable}
- Goal: ${goal}
- Available tools/resources: Computer with internet access, code editor (if applicable), browser, basic knowledge relevant to the hobby, and access to free online resources

Instructions:

Overview (3–4 sentences):
- Use a warm, beginner-friendly tone
- Highlight what the user will achieve in 7 days
- Encourage confidence and clarity in learning

Daily Mini-Lessons (Day 1 to Day 7):
Each lesson must include ALL the following labeled sections:

🎯 Main Task:
- Step-by-step actionable task suitable for beginners
- Include clear instructions, especially for research/discovery activities

📚 Explanation & Why:
- Explain the importance of the task in their learning journey
- Show how it connects with prior/future days

🔍 How to Find / Do / Use (if applicable):
- Detail exactly how to complete the task
- Mention free tools, platforms, and practical guidance

📋 Detailed Checklist (if applicable):
- List all tools, resources, or setup needs
- Briefly explain each item's role

⚠️ Common Mistakes to Avoid:
- 1 to 3 beginner mistakes with fixes

💡 Tips for Success:
- 2–3 practical and encouraging beginner tips

🔗 Free Resource:
- One active, beginner-friendly link (YouTube tutorial, blog, or free course)
- Must be high-quality and reputable

🛒 Affiliate Link:
- Provide 1 product/tool link relevant to each day's task

**Output Format:**
Return a valid JSON object with this exact structure:

{
  "hobby": "${hobby}",
  "overview": "A compelling 3-4 sentence description of what they'll achieve in 7 days",
  "days": [
    {
      "day": 1,
      "title": "Clear, actionable day title (max 6 words)",
      "mainTask": "Detailed step-by-step task with specific time requirements",
      "explanation": "Why this task is important and how it connects to the learning journey",
      "howToGuide": "Specific instructions on how to complete the task",
      "checklist": ["Item 1 - purpose", "Item 2 - purpose", "Item 3 - purpose"],
      "commonMistakes": ["Mistake 1 and how to fix it", "Mistake 2 and how to fix it"],
      "tips": ["Practical tip 1", "Encouraging tip 2", "Success tip 3"],
      "freeResource": {
        "title": "Descriptive title for a YouTube tutorial or article",
        "url": "https://youtube.com/watch?v=realistic-video-id"
      },
      "affiliateLink": {
        "title": "Realistic beginner tool/supply name",
        "url": "https://amazon.com/dp/PRODUCTID?tag=wizqo-20",
        "store": "Amazon"
      }
    }
    // ... repeat for days 2-7
  ]
}

**Important Guidelines:**
- Day 1 should be absolute beginner friendly
- Each day should take roughly ${timeAvailable}
- Tasks should be specific and measurable
- All sections must be filled with detailed, actionable content
- Free resource URLs should look realistic (use placeholder video IDs)
- Product links should use realistic Amazon product patterns
- Alternate between "Amazon" and "Michaels" for the store field
- Progressive difficulty: Day 1 = basics, Day 7 = first real project/achievement
- Focus on ${goal} throughout the plan

**Tone:** Encouraging, practical, beginner-friendly, detailed
**Focus:** ${goal} while building real skills step by step

Generate the complete 7-day plan now with all required sections filled.
```

## Example API Integration with Enhanced Structure

```typescript
import { DeepSeekAPI } from '../utils/deepseek-api';

const deepseek = new DeepSeekAPI(process.env.REACT_APP_DEEPSEEK_API_KEY!);

const generateEnhancedPlan = async (hobby: string, answers: QuizAnswers) => {
  try {
    const plan = await deepseek.generateEnhancedPlan(hobby, answers);
    return plan;
  } catch (error) {
    console.error('Enhanced plan generation failed:', error);
    return getFallbackPlan(hobby, answers);
  }
};
```

## Expected Response Structure

The API should return a JSON object with this structure:

- **hobby**: String - The hobby name
- **overview**: String - 3-4 sentence compelling description
- **days**: Array of objects with:
  - **day**: Number (1-7)
  - **title**: String (max 6 words)
  - **mainTask**: String (detailed step-by-step task)
  - **explanation**: String (why this task matters)
  - **howToGuide**: String (specific instructions)
  - **checklist**: Array of strings (tools/resources needed)
  - **commonMistakes**: Array of strings (mistakes and fixes)
  - **tips**: Array of strings (practical success tips)
  - **freeResource**: Object with title and URL
  - **affiliateLink**: Object with title, URL, and store

This enhanced structure provides comprehensive, actionable learning plans that guide users through every step of their 7-day journey.