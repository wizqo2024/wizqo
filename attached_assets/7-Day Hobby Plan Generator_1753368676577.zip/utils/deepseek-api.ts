interface QuizAnswers {
  experience: string;
  timeAvailable: string;
  goal: string;
}

interface DayPlan {
  day: number;
  title: string;
  mainTask: string;
  explanation: string;
  howToGuide: string;
  checklist: string[];
  commonMistakes: string[];
  tips: string[];
  freeResource: {
    title: string;
    url: string;
  };
  affiliateLink: {
    title: string;
    url: string;
    store: 'Amazon' | 'Michaels';
  };
}

interface PlanData {
  hobby: string;
  overview: string;
  days: DayPlan[];
}

export class DeepSeekAPI {
  private apiKey: string;
  private baseUrl: string = 'https://api.deepseek.com/v1/chat/completions';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  private buildEnhancedPrompt(hobby: string, answers: QuizAnswers): string {
    return `Generate a detailed, motivating, and beginner-level-appropriate 7-day learning plan for the hobby: ${hobby}.

User Details:
- Experience level: ${answers.experience}
- Time commitment per day: ${answers.timeAvailable}
- Goal: ${answers.goal}
- Available tools/resources: Computer with internet access, code editor (if applicable), browser, basic knowledge relevant to the hobby, and access to free online resources

Instructions:

Overview (3–4 sentences):
- Use a warm, beginner-friendly tone
- Highlight what the user will achieve in 7 days
- Encourage confidence and clarity in learning

Daily Mini-Lessons (Day 1 to Day 7):
Each lesson must include ALL the following labeled sections:

🎯 Main Task:
- Step-by-step actionable task suitable for beginners
- Include clear instructions, especially for research/discovery activities

📚 Explanation & Why:
- Explain the importance of the task in their learning journey
- Show how it connects with prior/future days

🔍 How to Find / Do / Use (if applicable):
- Detail exactly how to complete the task
- Mention free tools, platforms, and practical guidance

📋 Detailed Checklist (if applicable):
- List all tools, resources, or setup needs
- Briefly explain each item's role

⚠️ Common Mistakes to Avoid:
- 1 to 3 beginner mistakes with fixes

💡 Tips for Success:
- 2–3 practical and encouraging beginner tips

🔗 Free Resource:
- One active, beginner-friendly link (YouTube tutorial, blog, or free course)
- Must be high-quality and reputable

🛒 Affiliate Link:
- Provide 1 product/tool link relevant to each day's task

**Output Format:**
Return a valid JSON object with this exact structure:

{
  "hobby": "${hobby}",
  "overview": "A compelling 3-4 sentence description of what they'll achieve in 7 days",
  "days": [
    {
      "day": 1,
      "title": "Clear, actionable day title (max 6 words)",
      "mainTask": "Detailed step-by-step task with specific time requirements",
      "explanation": "Why this task is important and how it connects to the learning journey",
      "howToGuide": "Specific instructions on how to complete the task",
      "checklist": ["Item 1 - purpose", "Item 2 - purpose", "Item 3 - purpose"],
      "commonMistakes": ["Mistake 1 and how to fix it", "Mistake 2 and how to fix it"],
      "tips": ["Practical tip 1", "Encouraging tip 2", "Success tip 3"],
      "freeResource": {
        "title": "Descriptive title for a YouTube tutorial or article",
        "url": "https://youtube.com/watch?v=realistic-video-id"
      },
      "affiliateLink": {
        "title": "Realistic beginner tool/supply name",
        "url": "https://amazon.com/dp/PRODUCTID?tag=wizqo-20",
        "store": "Amazon"
      }
    }
  ]
}

**Important Guidelines:**
- Day 1 should be absolute beginner friendly
- Each day should take roughly ${answers.timeAvailable}
- Tasks should be specific and measurable
- All sections must be filled with detailed, actionable content
- Free resource URLs should look realistic (use placeholder video IDs like "example-video-123")
- Product links should use realistic Amazon product patterns with placeholder IDs
- Alternate between "Amazon" and "Michaels" for the store field
- Progressive difficulty: Day 1 = basics, Day 7 = first real project/achievement
- Focus on ${answers.goal} throughout the plan

**Tone:** Encouraging, practical, beginner-friendly, detailed
**Focus:** ${answers.goal} while building real skills step by step

Generate the complete 7-day plan now with all required sections filled. Ensure the response is valid JSON only.`;
  }

  async generateEnhancedPlan(hobby: string, answers: QuizAnswers): Promise<PlanData> {
    const prompt = this.buildEnhancedPrompt(hobby, answers);

    const response = await fetch(this.baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.7,
        max_tokens: 4000 // Increased for detailed content
      })
    });

    if (!response.ok) {
      throw new Error(`DeepSeek API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      throw new Error('Invalid response format from DeepSeek API');
    }

    let planData: PlanData;
    try {
      planData = JSON.parse(data.choices[0].message.content);
    } catch (error) {
      throw new Error('Failed to parse JSON response from DeepSeek API');
    }

    // Validate the enhanced response structure
    if (!this.validateEnhancedPlan(planData)) {
      throw new Error('Invalid enhanced plan structure returned from DeepSeek API');
    }

    return planData;
  }

  private validateEnhancedPlan(plan: any): plan is PlanData {
    if (!plan.hobby || !plan.overview || !Array.isArray(plan.days) || plan.days.length !== 7) {
      return false;
    }

    // Validate each day has required enhanced structure
    for (const day of plan.days) {
      if (
        !day.day || 
        !day.title || 
        !day.mainTask || 
        !day.explanation || 
        !day.howToGuide ||
        !Array.isArray(day.checklist) ||
        !Array.isArray(day.commonMistakes) ||
        !Array.isArray(day.tips) ||
        !day.freeResource?.title || 
        !day.freeResource?.url ||
        !day.affiliateLink?.title || 
        !day.affiliateLink?.url || 
        !day.affiliateLink?.store
      ) {
        return false;
      }
    }

    return true;
  }

  // Legacy method for backward compatibility
  async generatePlan(hobby: string, answers: QuizAnswers): Promise<PlanData> {
    return this.generateEnhancedPlan(hobby, answers);
  }
}

// Usage examples:
// const deepseek = new DeepSeekAPI(process.env.REACT_APP_DEEPSEEK_API_KEY!);
// const plan = await deepseek.generateEnhancedPlan('YouTube API Integration', { 
//   experience: 'Beginner', 
//   timeAvailable: '30-60 minutes', 
//   goal: 'Learn how to connect to the YouTube API and embed YouTube videos dynamically on a webpage' 
// });