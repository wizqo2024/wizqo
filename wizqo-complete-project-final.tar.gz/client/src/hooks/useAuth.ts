// This file now exports the context-based useAuth hook
export { useAuth } from '../context/AuthContext';